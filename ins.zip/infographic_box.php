	<div class="infographic-box">
				<div class="container">
					<h3>Some Infographic Elements</h3>
					<ul class="gender-list">
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-female"></i></a></li>
						<li><a href="#"><i class="fa fa-female"></i></a></li>
						<li><a href="#"><i class="fa fa-female"></i></a></li>
						<li><a href="#"><i class="fa fa-female"></i></a></li>
						<li><a href="#"><i class="fa fa-female"></i></a></li>
					</ul>
					<ul class="stars-list">
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
					</ul>

					<div class="skills-bar">
						<div class="row">
							<div class="col-md-2">
								<div id="circle" data-percent="50"></div>
								<p>Circular Progress Bar</p>
							</div>
							<div class="col-md-2">
								<div id="circle2" data-percent="39"></div>
								<p>Circular Progress Bar</p>
							</div>
							<div class="col-md-2">
								<div id="circle3" data-percent="90"></div>
								<p>Circular Progress Bar</p>
							</div>
							<div class="col-md-2">
								<div id="circle4" data-percent="60"></div>
								<p>Circular Progress Bar</p>
							</div>
							<div class="col-md-2">
								<div id="circle5" data-percent="80"></div>
								<p>Circular Progress Bar</p>
							</div>
							<div class="col-md-2">
								<div id="circle6" data-percent="45"></div>
								<p>Circular Progress Bar</p>
							</div>
						</div>
					</div>
				</div>
			</div>
