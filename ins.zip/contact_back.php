<!doctype html>


<html lang="en" class="no-js">
<head>
	<title>Convertible</title>

	<meta charset="utf-8">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,700,600,300' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/style.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="screen">


</head>
<body>

	<!-- Container -->
	<div id="container">
		<!-- Header
		    ================================================== -->
		<header class="clearfix">
			<!-- Static navbar -->
			<div class="navbar navbar-default navbar-fixed-top">
				<div class="top-line">
					<div class="container">
						<p>
							<span><i class="fa fa-phone"></i>1234 - 5678 - 9012</span>
							<span><i class="fa fa-envelope-o"></i>support@convertible.com</span>
						</p>
						<ul class="social-icons">
							<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
							<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
							<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
							<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#"><img alt="" src="images/logo.png"></a>
					</div>
					<div class="navbar-collapse collapse">
						<ul class="nav navbar-nav navbar-right">

							<li class="drop"><a href="index.html">Home</a>
								<ul class="drop-down">
									<li><a href="index.html">Home Default</a></li>
									<li><a href="home-shop.html">Home Shop</a></li>
									<li><a href="home-portfolio.html">Home Portfolio</a></li>
									<li><a href="home-blog.html">Home blog</a></li>
									<li><a href="single-page.html">Single Page</a></li>
									<li><a href="home-boxed.html">Home Boxed</a></li>
								</ul>
							</li>
							<li class="drop"><a href="index.html">Sliders</a>
								<ul class="drop-down">
									<li><a href="index.html">Revolution slider</a></li>
									<li><a href="flexslider.html">Flexslider</a></li>
								</ul>
							</li>
							<li><a href="about.html">About Us</a></li>
							<li class="drop"><a href="blog-right-sidebar.html">Blog</a>
								<ul class="drop-down">
									<li><a href="blog-one-col.html">Blog 1col</a></li>
									<li><a href="blog-two-col.html">Blog 2col</a></li>
									<li><a href="blog-right-sidebar.html">Blog right sidebar</a></li>
									<li><a href="blog-left-sidebar.html">Blog left sidebar</a></li>
									<li><a href="blog-nosidebar.html">Blog no sidebar</a></li>
								</ul>
							</li>
							<li class="drop"><a href="portfolio-4col.html">Portfolio</a>
								<ul class="drop-down">
									<li><a href="portfolio-2col.html">Portfolio 2col</a></li>
									<li><a href="portfolio-3col.html">Portfolio 3col</a></li>
									<li><a href="portfolio-4col.html">Portfolio 4col</a></li>
								</ul>
							</li>
							<li><a href="shop.html">Shop</a></li>
							<li class="drop"><a href="#">Pages</a>
								<ul class="drop-down">
									<li><a href="single-post.html">Single Post</a></li>
									<li><a href="single-project.html">Single Project</a></li>
								</ul>
							</li>
							<li><a class="active" href="contact.html">Contact Us</a></li>

						</ul>
					</div>
				</div>
			</div>
		</header>
		<!-- End Header -->

		<!-- content 
			================================================== -->
		<div id="content">

			<!-- Page Banner -->
			<div class="page-banner">
				<div class="container">
					<h2>Contact Us</h2>
					<ul class="page-tree">
						<li><a href="#">Home</a></li>
						<li><a href="#">Contact</a></li>
					</ul>		
				</div>
			</div>

			<!-- Map box -->
			<div class="map">
				
			</div>

			<!-- contact box -->
			<div class="contact-box">
				<div class="container">
					<div class="row">

						<div class="col-md-3">
							<div class="contact-information">
								<h3>Contact info</h3>
								<ul class="contact-information-list">
									<li><span><i class="fa fa-home"></i>lorem ipsum street</span></li>
									<li><span><i class="fa fa-phone"></i>9930 1234 5679</span></li>
									<li><a href="#"><i class="fa fa-envelope"></i>info@orbit7.com</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3">
							<div class="contact-information">
								<h3>Working hours</h3>
								<p>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit duis set odio sit amet nibh vulputate cursus </p>
								<p class="work-time"><span>Mon - Fri</span> : 10 AM to 5 PM</p>
								<p class="work-time"><span>Sat - Sun</span> : 10 AM to 2 PM</p>
							</div>
						</div>

						<div class="col-md-6">
							<h3>Send us a message</h3>
							<form id="contact-form" class="contact-work-form2">

								<div class="text-input">
									<div class="float-input">
										<input name="name" id="name2" type="text" placeholder="name">
										<span><i class="fa fa-user"></i></span>
									</div>

									<div class="float-input2">
										<input name="mail" id="mail2" type="text" placeholder="email">
										<span><i class="fa fa-envelope"></i></span>
									</div>
								</div>

								<div class="textarea-input">
									<textarea name="comment" id="comment2" placeholder="message"></textarea>
									<span><i class="fa fa-comment"></i></span>
								</div>

								<div class="msg2 message"></div>
								<input type="submit" name="mailing-submit" class="submit_contact main-form" value="Send Message">

							</form>
						</div>

					</div>
				</div>
			</div>

		</div>
		<!-- End content -->


		<!-- footer 
			================================================== -->
		<footer>
			<div class="up-footer">
				<div class="container">
					<div class="row">

						<div class="col-md-3">
							<div class="widget footer-widgets text-widget">
								<img alt="" src="images/logo.png">
								<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem</p>
							</div>
							<div class="widget footer-widgets twitter-widget">
								<h4>Recent Tweets</h4>
								<ul class="tweets">
									<li>
										<p><a class="tweet-acc" href="#">@premiumlayers</a> Thanks for the head up! :) <a href="#">http://support.envato.com</a> was very helpful</p>
										<span>3 days ago</span>
									</li>
									<li>
										<p><a class="tweet-acc" href="#">@envato</a> <a href="#">http://support.envato.com</a> </p>
										<span>4 days ago</span>
									</li>
								</ul>
							</div>
						</div>

						<div class="col-md-3">
							<div class="widget footer-widgets flickr-widget">
								<h4>Flickr Gallery</h4>
								<ul class="flickr-list">
									<li><a href="#"><img alt="" src="images/flickr1.png"></a></li>
									<li><a href="#"><img alt="" src="images/flickr2.png"></a></li>
									<li><a href="#"><img alt="" src="images/flickr3.png"></a></li>
									<li><a href="#"><img alt="" src="images/flickr4.png"></a></li>
									<li><a href="#"><img alt="" src="images/flickr5.png"></a></li>
									<li><a href="#"><img alt="" src="images/flickr6.png"></a></li>
								</ul>
							</div>
							<div class="widget footer-widgets popular-widget">
								<h4>Popular Posts</h4>
								<ul class="pop-post">
									<li><a href="#"><i class="fa fa-pencil-square-o"></i> New Search Platform Update</a></li>
									<li><a href="#"><i class="fa fa-pencil-square-o"></i> Envato's Most Wanted - $5,000 for Ghost Themes</a></li>
									<li><a href="#"><i class="fa fa-pencil-square-o"></i> Update: WordPress Theme Submission Requirements</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3">
							<div class="widget footer-widgets tag-widget">
								<h4>Tags</h4>
								<ul class="tag-widget-list">
									<li><a href="#">web design</a></li>
									<li><a href="#">coding</a></li>
									<li><a href="#">wordpress</a></li>
									<li><a href="#">woo commerce</a></li>
									<li><a href="#">php</a></li>
									<li><a href="#">photography</a></li>
								</ul>
							</div>
							<div class="widget footer-widgets message-widget">
								<h4>Send Message</h4>
								<form id="footer-contact" class="contact-work-form">
									<input type="text" name="name" id="name" placeholder="Name"/>
									<input type="text" name="mail" id="mail" placeholder="Email"/>
									<textarea name="comment" id="comment" placeholder="Message"></textarea>
									<button type="submit" name="contact-submit" class="submit_contact">
										<i class="fa fa-envelope"></i> Send
									</button>
									<div class="msg"></div>
								</form>
							</div>
						</div>

						<div class="col-md-3">
							<div class="widget footer-widgets info-widget">
								<h4>Contact Us</h4>
								<ul class="contact-list">
									<li><a class="phone" href="#"><i class="fa fa-phone"></i>9930 1234 5679</a></li>
									<li><a class="mail" href="#"><i class="fa fa-envelope"></i> contact@yourdomain.com</a></li>
									<li><a class="address" href="#"><i class="fa fa-home"></i> street address example</a></li>
								</ul>
							</div>
							<div class="widget footer-widgets work-widget">
								<h4>Working Hours</h4>
								<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum </p>
								<p class="work-time"><span>Mon - Fri</span> : 10 AM to 5 PM</p>
								<p class="work-time"><span>Sat - Sun</span> : 10 AM to 2 PM</p>
							</div>
						</div>

					</div>
				</div>
			</div>

			<div class="footer-line">
				<div class="container">
					<p>&#169; 2013 Convertible,  All Rights Reserved</p>
					<a class="go-top" href="#"></a>
				</div>
			</div>

		</footer>
		<!-- End footer -->
	</div>
	<!-- End Container -->

	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.migrate.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
  	<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
	<script type="text/javascript" src="js/gmap3.min.js"></script>
	<script type="text/javascript" src="js/retina-1.1.0.min.js"></script>
	<script type="text/javascript" src="js/plugins-scroll.js"></script>
	<script type="text/javascript" src="js/script.js"></script>

	<!--[if lt IE 9]>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
</body>
</html>