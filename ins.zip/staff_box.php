	<div class="staff-box">
				<div class="container">
					<h3>Our Staff</h3>
					<div id="carousel-example-generic3" class="carousel slide" data-ride="carousel">

						<!-- Wrapper for slides -->
						<div class="carousel-inner">

							<div class="item active">
								<div class="row">
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team1.jpg">
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team2.jpg">
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team3.jpg">
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team4.jpg">
											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="item">
								<div class="row">
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team1.jpg">
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team2.jpg">
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team3.jpg">
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team4.jpg">
											</div>
										</div>
									</div>
								</div>
							</div>

						</div>
						<!-- Controls -->
						<a class="left carousel-control" href="#carousel-example-generic3" data-slide="prev">
							<span class="glyphicon glyphicon-chevron-left"></span>
						</a>
						<a class="right carousel-control" href="#carousel-example-generic3" data-slide="next">
							<span class="glyphicon glyphicon-chevron-right"></span>
						</a>
					</div>
				</div>
			</div>