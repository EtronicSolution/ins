<div class="latest-post">
				<div class="title-section">
					<h1>Latest Post</h1>
					<p>clean horizontal post scroller for your creative website</p>
				</div>
				<div id="owl-demo" class="owl-carousel owl-theme">
          
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo1.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit </p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo2.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit </p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo3.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit</p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo1.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit</p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo2.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit</p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo3.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit</p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo1.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit</p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo2.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit</p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
				 
				</div>
			</div>