  <!-- Left Sidebar  -->
        <div class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebar-menu">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>
                        <li> <a  href="home.php" aria-expanded="false"><i class="fa fa-tachometer"></i><span class="hide-menu">Dashboard </span></a>
                           
                        
                        
                        <li class="nav-label">My Team</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fas fa-user-times"></i><span class="hide-menu">User</span></a>
                            <ul aria-expanded="false" class="collapse">
                                 <li><a class="fa fa-user" href="members_list.php?type=user">  List</a></li>
                                 
                              
                            </ul>
                        </li>
                        
                       
                      <li class="nav-label">My Point wallet</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-pencil-square-o"></i><span class="hide-menu">View Point History </span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a class="fa fa-dollar" href="deposit_list_pending.php">  View Point History </a></li>
                               
                            </ul>
                        </li>
                        
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fas fa-retweet"></i><span class="hide-menu">  My profile Settings</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a class="fa fa-dollar" href="packages_list.php">   My Profile</a></li>
                                       
                            </ul>
                        </li>
                   
                        <li> <a class="nav-label"  href="javascript:logout()" aria-expanded="false"><i class="fa fa-sign-out"></i><span class="hide-menu">Log Out</span></a>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </div>
        <!-- End Left Sidebar  -->