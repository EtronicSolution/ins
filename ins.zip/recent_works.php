<div class="recent-works">
				<div class="container">
					<h3>Recent Works</h3>
					<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

						<!-- Wrapper for slides -->
						<div class="carousel-inner">

							<div class="item active">
								<div class="row">

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image1.jpg">
												<div class="hover-box">
													<a class="zoom video" href="http://www.youtube.com/watch?v=XSGBVzeBUbk"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Iphone Wallpaper</h5>
												<span>smartphones</span>
											</div>
										</div>
									</div>

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image2.jpg">
												<div class="hover-box">
													<a class="zoom" href="upload/image2.jpg"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Green Leaf Falling Dawn</h5>
												<span>nature</span>
											</div>										
										</div>
									</div>

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image3.jpg">
												<div class="hover-box">
													<a class="zoom video" href="http://www.youtube.com/watch?v=6v2L2UGZJAM"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Beautiful Wallpaper</h5>
												<span>wallpaper</span>
											</div>										
										</div>
									</div>

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image4.jpg">
												<div class="hover-box">
													<a class="zoom" href="upload/image4.jpg"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Futuristic Office Design</h5>
												<span>furniture</span>
											</div>										
										</div>
									</div>

								</div>
							</div>

							<div class="item">
								<div class="row">

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image1.jpg">
												<div class="hover-box">
													<a class="zoom video" href="http://vimeo.com/45878034"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Iphone Wallpaper</h5>
												<span>smartphones</span>
											</div>
										</div>
									</div>

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image2.jpg">
												<div class="hover-box">
													<a class="zoom" href="upload/image2.jpg"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Green Leaf Falling Dawn</h5>
												<span>nature</span>
											</div>										
										</div>
									</div>

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image3.jpg">
												<div class="hover-box">
													<a class="zoom" href="upload/image3.jpg"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Beautiful Wallpaper</h5>
												<span>wallpaper</span>
											</div>										
										</div>
									</div>

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image4.jpg">
												<div class="hover-box">
													<a class="zoom" href="upload/image4.jpg"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Futuristic Office Design</h5>
												<span>furniture</span>
											</div>										
										</div>
									</div>

								</div>

							</div>

						</div>

						<!-- Controls -->
						<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev"></a>
						<a class="right carousel-control" href="#carousel-example-generic" data-slide="next"></a>
					</div>
				</div>
			</div>