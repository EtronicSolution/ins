<!doctype html>


<html lang="en" class="no-js">
<head>
	<title>Convertible</title>

	<meta charset="utf-8">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,700,600,300' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
    <!-- REVOLUTION BANNER CSS SETTINGS -->
    <link rel="stylesheet" type="text/css" href="css/fullwidth.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="css/settings.css" media="screen" />
	
	<link rel="stylesheet" type="text/css" href="css/magnific-popup.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" media="screen">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/jquery.bxslider.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/style.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="screen">


	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.migrate.js"></script>
	<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/raphael-min.js"></script>
	<script type="text/javascript" src="js/DevSolutionSkill.min.js"></script>
	<script type="text/javascript" src="js/retina-1.1.0.min.js"></script>
	<script type="text/javascript" src="js/jquery.bxslider.min.js"></script>
	<script type="text/javascript" src="js/plugins-scroll.js"></script>

     <!-- jQuery KenBurn Slider  -->
    <script type="text/javascript" src="js/jquery.themepunch.revolution.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>

	<!--[if lt IE 9]>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
</head>
<body>

	<!-- Container -->
	<div id="container">
		<!-- Header
		    ================================================== -->
		<header class="clearfix">
			<!-- Static navbar -->
			<div class="navbar navbar-default navbar-fixed-top">
				<div class="top-line">
					<div class="container">
						<p>
							<span><i class="fa fa-phone"></i>1234 - 5678 - 9012</span>
							<span><i class="fa fa-envelope-o"></i>support@convertible.com</span>
						</p>
						<ul class="social-icons">
							<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
							<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
							<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
							<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#"><img alt="" src="images/logo.png"></a>
					</div>
					<div class="navbar-collapse collapse">
						<ul class="nav navbar-nav navbar-right">

							<li class="drop"><a class="active" href="index.html">Home</a>
								<ul class="drop-down">
									<li><a href="index.html">Home Default</a></li>
									<li><a href="home-shop.html">Home Shop</a></li>
									<li><a href="home-portfolio.html">Home Portfolio</a></li>
									<li><a href="home-blog.html">Home blog</a></li>
									<li><a href="single-page.html">Single Page</a></li>
									<li><a href="home-boxed.html">Home Boxed</a></li>
									<li class="drop"><a href="#">Level 3</a>
										<ul class="drop-down level3">
											<li><a href="#">Level 3</a></li>
											<li><a href="#">Level 3</a></li>
											<li><a href="#">Level 3</a></li>
										</ul>
									</li>									
								</ul>
							</li>
							<li class="drop"><a href="index.html">Sliders</a>
								<ul class="drop-down">
									<li><a href="index.html">Revolution slider</a></li>
									<li><a href="flexslider.html">Flexslider</a></li>
								</ul>
							</li>
							<li><a href="about.html">About Us</a></li>
							<li class="drop"><a href="blog-right-sidebar.html">Blog</a>
								<ul class="drop-down">
									<li><a href="blog-one-col.html">Blog 1col</a></li>
									<li><a href="blog-two-col.html">Blog 2col</a></li>
									<li><a href="blog-right-sidebar.html">Blog right sidebar</a></li>
									<li><a href="blog-left-sidebar.html">Blog left sidebar</a></li>
									<li><a href="blog-nosidebar.html">Blog no sidebar</a></li>
								</ul>
							</li>
							<li class="drop"><a href="portfolio-4col.html">Portfolio</a>
								<ul class="drop-down">
									<li><a href="portfolio-2col.html">Portfolio 2col</a></li>
									<li><a href="portfolio-3col.html">Portfolio 3col</a></li>
									<li><a href="portfolio-4col.html">Portfolio 4col</a></li>
								</ul>
							</li>
							<li><a href="shop.html">Shop</a></li>
							<li class="drop"><a href="#">Pages</a>
								<ul class="drop-down">
									<li><a href="single-post.html">Single Post</a></li>
									<li><a href="single-project.html">Single Project</a></li>
								</ul>
							</li>
							<li><a href="contact.html">Contact Us</a></li>

						</ul>
					</div>
				</div>
			</div>
		</header>
		<!-- End Header -->

		<!-- slider 
			================================================== -->
		<div id="slider">
			<!--
			#################################
				- THEMEPUNCH BANNER -
			#################################
			-->

			<div class="fullwidthbanner-container">
				<div class="fullwidthbanner">
					<ul>
						<!-- THE FIRST SLIDE -->
						<li data-transition="3dcurtain-vertical" data-slotamount="10" data-masterspeed="300">
							<!-- THE MAIN IMAGE IN THE FIRST SLIDE -->
							<img alt="" src="upload/slider-revolution/1.jpg" >

							<!-- THE CAPTIONS IN THIS SLDIE -->
							<div class="caption large_text sfb"
								 data-x="170"
								 data-y="128"
								 data-speed="600"
								 data-start="1200"
								 data-easing="easeOutExpo" data-end="7000" data-endspeed="300" data-endeasing="easeInSine" >Welcome to the Most Complete Html Template</div>

							<div class="caption big_white sft stt"
								 data-x="370"
								 data-y="185"
								 data-speed="500"
								 data-start="1400"
								 data-easing="easeOutExpo" data-end="7100" data-endspeed="300" data-endeasing="easeInSine" ><span>Convertible</span> - Creative All Purpose Design</div>

							<div class="caption randomrotate"
								 data-x="0"
								 data-y="244"
								 data-speed="600"
								 data-start="1600"
								 data-easing="easeOutExpo" data-end="7200" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon1.png" alt="Image 1"></div>

							<div class="caption modern_small_text_dark sft"
								 data-x="45"
								 data-y="360"
								 data-speed="600"
								 data-start="1700"
								 data-easing="easeOutExpo" data-end="7350" data-endspeed="300" data-endeasing="easeInSine" >Lovely design</div>

							<div class="caption randomrotate"
								 data-x="200"
								 data-y="244"
								 data-speed="600"
								 data-start="1800"
								 data-easing="easeOutExpo" data-end="7400" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon2.png" alt="Image 2"></div>

							<div class="caption modern_small_text_dark sft"
								 data-x="222"
								 data-y="360"
								 data-speed="600"
								 data-start="1900"
								 data-easing="easeOutExpo" data-end="7450" data-endspeed="300" data-endeasing="easeInSine" >Highly Customizable</div>

							<div class="caption randomrotate"
								 data-x="400"
								 data-y="244"
								 data-speed="600"
								 data-start="2000"
								 data-easing="easeOutExpo" data-end="7500" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon3.png" alt="Image 3"></div>

							<div class="caption modern_small_text_dark sft"
								 data-x="429"
								 data-y="360"
								 data-speed="600"
								 data-start="2100"
								 data-easing="easeOutExpo" data-end="7550" data-endspeed="300" data-endeasing="easeInSine" >Optimized Images</div>

							<div class="caption randomrotate"
								 data-x="600"
								 data-y="244"
								 data-speed="600"
								 data-start="2200"
								 data-easing="easeOutExpo" data-end="7600" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon4.png" alt="Image 4"></div>

							<div class="caption modern_small_text_dark sft"
								 data-x="641"
								 data-y="360"
								 data-speed="600"
								 data-start="2300"
								 data-easing="easeOutExpo" data-end="7650" data-endspeed="300" data-endeasing="easeInSine" >5 Star Support</div>

							<div class="caption randomrotate"
								 data-x="800"
								 data-y="244"
								 data-speed="600"
								 data-start="2400"
								 data-easing="easeOutExpo" data-end="7700" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon5.png" alt="Image 5"></div>

							<div class="caption modern_small_text_dark sft"
								 data-x="838"
								 data-y="360"
								 data-speed="600"
								 data-start="2500"
								 data-easing="easeOutExpo" data-end="7750" data-endspeed="300" data-endeasing="easeInSine" >Update Notifier</div>

							<div class="caption randomrotate"
								 data-x="1000"
								 data-y="244"
								 data-speed="600"
								 data-start="2600"
								 data-easing="easeOutExpo" data-end="7800" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon6.png" alt="Image 6"></div>

							<div class="caption modern_small_text_dark sft"
								 data-x="1047"
								 data-y="360"
								 data-speed="600"
								 data-start="2700"
								 data-easing="easeOutExpo" data-end="7850" data-endspeed="300" data-endeasing="easeInSine" >Fast Loading</div>
						</li>
						<!-- THE second SLIDE -->
						<li data-transition="papercut" data-slotamount="15" data-masterspeed="300">
							<!-- THE MAIN IMAGE IN THE second SLIDE -->
							<img alt="" src="upload/slider-revolution/2.jpg" >

							<!-- THE CAPTIONS IN THIS SLDIE -->

							<div class="caption randomrotate"
								 data-x="720"
								 data-y="130"
								 data-speed="600"
								 data-start="1200"
								 data-easing="easeOutExpo" data-end="7000" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/image.png" alt="Image 1"></div>

							<div class="caption modern_medium_light sft stt"
								 data-x="110"
								 data-y="148"
								 data-speed="500"
								 data-start="1500"
								 data-easing="easeOutExpo" data-end="7100" data-endspeed="300" data-endeasing="easeInSine" ><i class="fa fa-list"></i>Shortcode Generator</div>

							<div class="caption modern_medium_light sft stt"
								 data-x="394"
								 data-y="148"
								 data-speed="600"
								 data-start="1600"
								 data-easing="easeOutExpo" data-end="7300" data-endspeed="300" data-endeasing="easeInSine" ><i class="fa fa-building-o"></i>Optimized Code</div>

							<div class="caption modern_medium_light sft stt"
								 data-x="110"
								 data-y="294"
								 data-speed="600"
								 data-start="1800"
								 data-easing="easeOutExpo" data-end="7400" data-endspeed="300" data-endeasing="easeInSine" ><i class="fa fa-flag-o"></i>Font Awesome</div>

							<div class="caption modern_medium_light sft stt"
								 data-x="394"
								 data-y="294"
								 data-speed="600"
								 data-start="2000"
								 data-easing="easeOutExpo" data-end="7500" data-endspeed="300" data-endeasing="easeInSine" ><i class="fa fa-laptop"></i> Retina Ready</div>
						</li>

						<!-- THE third SLIDE -->
						<li data-transition="turnoff" data-slotamount="1" data-masterspeed="300">
							<!-- THE MAIN IMAGE IN THE third SLIDE -->
							<img alt="" src="upload/slider-revolution/3.jpg" >

							<!-- THE CAPTIONS IN THIS SLDIE -->
							<div class="caption large_text sfb"
								 data-x="0"
								 data-y="185"
								 data-speed="600"
								 data-start="1200"
								 data-easing="easeOutExpo" data-end="7000" data-endspeed="300" data-endeasing="easeInSine" >Hello and welcome to <span> Convertible</span></div>

							<div class="caption medium_grey sft stt"
								 data-x="0"
								 data-y="224"
								 data-speed="500"
								 data-start="1300"
								 data-easing="easeOutExpo" data-end="7100" data-endspeed="300" data-endeasing="easeInSine" >another creative html template brought to you by Premium Layers</div>

							<div class="caption randomrotate"
								 data-x="0"
								 data-y="273"
								 data-speed="600"
								 data-start="1400"
								 data-easing="easeOutExpo" data-end="7200" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon7.png" alt="Image 1"></div>

							<div class="caption randomrotate"
								 data-x="129"
								 data-y="273"
								 data-speed="600"
								 data-start="1500"
								 data-easing="easeOutExpo" data-end="7300" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon8.png" alt="Image 2"></div>

							<div class="caption randomrotate"
								 data-x="259"
								 data-y="273"
								 data-speed="600"
								 data-start="1600"
								 data-easing="easeOutExpo" data-end="7400" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon9.png" alt="Image 3"></div>

							<div class="caption randomrotate"
								 data-x="390"
								 data-y="273"
								 data-speed="600"
								 data-start="1700"
								 data-easing="easeOutExpo" data-end="7500" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon10.png" alt="Image 4"></div>

							<div class="caption big_white sfb"
								 data-x="520"
								 data-y="337"
								 data-speed="600"
								 data-start="1900"
								 data-easing="easeOutExpo" data-end="7000" data-endspeed="300" data-endeasing="easeInSine" ><span>Retina</span> Ready Icons</div>

							<div class="caption randomrotate"
								 data-x="587"
								 data-y="387"
								 data-speed="600"
								 data-start="2100"
								 data-easing="easeOutExpo" data-end="7600" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon12.png" alt="Image 5"></div>

							<div class="caption randomrotate"
								 data-x="684"
								 data-y="375"
								 data-speed="700"
								 data-start="2200"
								 data-easing="easeOutExpo" data-end="7900" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon13.png" alt="Image 6"></div>

							<div class="caption randomrotate"
								 data-x="739"
								 data-y="348"
								 data-speed="600"
								 data-start="2300"
								 data-easing="easeOutExpo" data-end="8000" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon14.png" alt="Image 7"></div>

							<div class="caption randomrotate"
								 data-x="808"
								 data-y="200"
								 data-speed="600"
								 data-start="2500"
								 data-easing="easeOutExpo" data-end="8300" data-endspeed="300" data-endeasing="easeInSine" ><img src="images/slider-icons/icon11.png" alt="Image 10"></div>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- End slider -->

		<!-- content 
			================================================== -->
		<div id="content">

			<!-- welcome-box -->
			<div class="welcome-box">
				<div class="container">
					<h1>Hello And Welcome To <span>Convertible</span></h1>
					<p>We’re an interactive agency specialising in lean UX and intelligent product and identity design</p>
				</div>
			</div>

			<!-- services-box -->
			<div class="services-box">
				<div class="container">
					<div class="row">

						<div class="col-md-4">
							<div class="services-post">
								<a class="services-icon1" href="#"><i class="fa fa-cogs"></i></a>
								<div class="services-post-content">
									<h4>Multipurpose</h4>
									<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p>
								</div>
							</div>
						</div>

						<div class="col-md-4">
							<div class="services-post">
								<a class="services-icon2" href="#"><i class="fa fa-desktop"></i></a>
								<div class="services-post-content">
									<h4>Flexible Design</h4>
									<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p>
								</div>
							</div>
						</div>

						<div class="col-md-4">
							<div class="services-post">
								<a class="services-icon3" href="#"><i class="fa fa-book"></i></a>
								<div class="services-post-content">
									<h4>Extended Docs</h4>
									<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p>
								</div>
							</div>
						</div>

					</div>
				</div>
				<img class="shadow-image" alt="" src="images/shadow.png">
			</div>

			<!-- recent-works-box -->
			<div class="recent-works">
				<div class="container">
					<h3>Recent Works</h3>
					<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

						<!-- Wrapper for slides -->
						<div class="carousel-inner">

							<div class="item active">
								<div class="row">

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image1.jpg">
												<div class="hover-box">
													<a class="zoom video" href="http://www.youtube.com/watch?v=XSGBVzeBUbk"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Iphone Wallpaper</h5>
												<span>smartphones</span>
											</div>
										</div>
									</div>

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image2.jpg">
												<div class="hover-box">
													<a class="zoom" href="upload/image2.jpg"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Green Leaf Falling Dawn</h5>
												<span>nature</span>
											</div>										
										</div>
									</div>

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image3.jpg">
												<div class="hover-box">
													<a class="zoom video" href="http://www.youtube.com/watch?v=6v2L2UGZJAM"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Beautiful Wallpaper</h5>
												<span>wallpaper</span>
											</div>										
										</div>
									</div>

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image4.jpg">
												<div class="hover-box">
													<a class="zoom" href="upload/image4.jpg"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Futuristic Office Design</h5>
												<span>furniture</span>
											</div>										
										</div>
									</div>

								</div>
							</div>

							<div class="item">
								<div class="row">

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image1.jpg">
												<div class="hover-box">
													<a class="zoom video" href="http://vimeo.com/45878034"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Iphone Wallpaper</h5>
												<span>smartphones</span>
											</div>
										</div>
									</div>

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image2.jpg">
												<div class="hover-box">
													<a class="zoom" href="upload/image2.jpg"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Green Leaf Falling Dawn</h5>
												<span>nature</span>
											</div>										
										</div>
									</div>

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image3.jpg">
												<div class="hover-box">
													<a class="zoom" href="upload/image3.jpg"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Beautiful Wallpaper</h5>
												<span>wallpaper</span>
											</div>										
										</div>
									</div>

									<div class="col-md-3">
										<div class="work-post">
											<div class="work-post-gal">
												<img alt="" src="upload/image4.jpg">
												<div class="hover-box">
													<a class="zoom" href="upload/image4.jpg"></a>
													<a class="page" href="single-project.html"></a>
												</div>
											</div>
											<div class="work-post-content">
												<h5>Futuristic Office Design</h5>
												<span>furniture</span>
											</div>										
										</div>
									</div>

								</div>

							</div>

						</div>

						<!-- Controls -->
						<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev"></a>
						<a class="right carousel-control" href="#carousel-example-generic" data-slide="next"></a>
					</div>
				</div>
			</div>

			<!-- partners box -->
			<div class="partners">
				<div class="container">
					<h3>Partners</h3>
					<div id="carousel-example-generic2" class="carousel slide" data-ride="carousel">

						<!-- Wrapper for slides -->
						<div class="carousel-inner">

							<div class="item active">
								<ul class="partner-list">
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
								</ul>
							</div>

							<div class="item">
								<ul class="partner-list">
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
								</ul>
							</div>

						</div>

						<!-- Controls -->
						<a class="left carousel-control" href="#carousel-example-generic2" data-slide="prev"></a>
						<a class="right carousel-control" href="#carousel-example-generic2" data-slide="next"></a>
					</div>
					
				</div>
			</div>

			<!-- Latest Post -->
			<div class="latest-post">
				<div class="title-section">
					<h1>Latest Post</h1>
					<p>clean horizontal post scroller for your creative website</p>
				</div>
				<div id="owl-demo" class="owl-carousel owl-theme">
          
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo1.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit </p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo2.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit </p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo3.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit</p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo1.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit</p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo2.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit</p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo3.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit</p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo1.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit</p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
					<div class="item news-item">
						<div class="inner-item">
							<img alt="" src="upload/photo2.jpg">
							<div class="hover-item">
								<ul>
									<li><a class="autor" href="#"><i class="fa fa-user"></i> TrendyStuff</a></li>
									<li><a class="date" href="#"><i class="fa fa-clock-o"></i> 19 October, 2013</a></li>
									<li><a class="comment-numb" href="#"><i class="fa fa-comments"></i> 16 Comments</a></li>
								</ul>
							</div>
						</div>
						<h5>Killing the author quiz but no let up on the review process</h5>
						<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit</p>
						<a class="read-more" href="single-post.html">read more <i class="fa fa-arrow-right"></i></a>
						
					</div>
				 
				</div>
			</div>

			<!-- WHY convertible box -->
			<div class="why-convertible-box">
				<div class="container">
					<div class="upper-box">
						<div class="row">
							<div class="col-md-6">
								<h1>Why choose <span>Convertible</span><i class="fa fa-question-circle"></i></h1>
								<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. <a href="#">Duis sed</a> odio sit amet nibh vulputate cursus a sit amet mauris. </p>
								<p>Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non  mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Mauris in erat justo. Nullam ac urna eu felis dapibus condimentum sit amet a augue. </p>
							</div>
							<div class="col-md-6">
								<ul class="tag-list">
									<li><a href="#"><i class="fa fa-check-circle"></i>fully responsive</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>localisation support</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>semantic and clean html/css</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>woocomerce support</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>custom widgets</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>filterable portfolio</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>+600 google fonts</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>ajax contact form</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>powerful admin</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>layered psd's</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>cooming soon page</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>retina ready</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="down-box">
						<ul class="device-list">
							<li><img alt="" src="images/device1.png"></li>
							<li class="device2"><img alt="" src="images/device2.png"></li>
							<li class="device3"><img alt="" src="images/device3.png"></li>
							<li class="device4"><img alt="" src="images/device4.png"></li>
						</ul>
					</div>
				</div>
			</div>

			<!-- client-testimonials -->
			<div class="testimonials-box">
				<div class="container">
					<h3>Client Testimonials</h3>
				</div>
				<ul class="bxslider">
					<li>
						<div class="container">
							<img alt="" src="images/client.png">
							<div class="message-content">
								<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum,</p>
								<h6>John Smith, CEO at <span>Envato</span></h6>
							</div>
						</div>
					</li>
					<li>
						<div class="container">
							<img alt="" src="images/client.png">
							<div class="message-content">
								<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum,</p>
								<h6>John Smith, CEO at <span>Envato</span></h6>
							</div>
						</div>
					</li>
					<li>
						<div class="container">
							<img alt="" src="images/client.png">
							<div class="message-content">
								<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum,</p>
								<h6>John Smith, CEO at <span>Envato</span></h6>
							</div>
						</div>
					</li>
				</ul>
			</div>

			<!-- staff-box -->
			<div class="staff-box">
				<div class="container">
					<h3>Our Staff</h3>
					<div id="carousel-example-generic3" class="carousel slide" data-ride="carousel">

						<!-- Wrapper for slides -->
						<div class="carousel-inner">

							<div class="item active">
								<div class="row">
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team1.jpg">
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team2.jpg">
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team3.jpg">
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team4.jpg">
											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="item">
								<div class="row">
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team1.jpg">
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team2.jpg">
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team3.jpg">
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="staff-post">
											<div class="staff-post-content">
												<h5>Owen Miller</h5>
												<span>manager</span>
											</div>
											<div class="staff-post-gal">
												<ul class="staf-social">
													<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
													<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
													<li><a class="rss" href="#"><i class="fa fa-rss"></i></a></li>
													<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
													<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
													<li><a class="pinterest" href="#"><i class="fa fa-pinterest"></i></a></li>
												</ul>
												<img alt="" src="upload/team4.jpg">
											</div>
										</div>
									</div>
								</div>
							</div>

						</div>
						<!-- Controls -->
						<a class="left carousel-control" href="#carousel-example-generic3" data-slide="prev">
							<span class="glyphicon glyphicon-chevron-left"></span>
						</a>
						<a class="right carousel-control" href="#carousel-example-generic3" data-slide="next">
							<span class="glyphicon glyphicon-chevron-right"></span>
						</a>
					</div>
				</div>
			</div>

			<div class="infographic-box">
				<div class="container">
					<h3>Some Infographic Elements</h3>
					<ul class="gender-list">
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-male"></i></a></li>
						<li><a href="#"><i class="fa fa-female"></i></a></li>
						<li><a href="#"><i class="fa fa-female"></i></a></li>
						<li><a href="#"><i class="fa fa-female"></i></a></li>
						<li><a href="#"><i class="fa fa-female"></i></a></li>
						<li><a href="#"><i class="fa fa-female"></i></a></li>
					</ul>
					<ul class="stars-list">
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
						<li><a href="#"><i class="fa fa-star"></i></a></li>
					</ul>

					<div class="skills-bar">
						<div class="row">
							<div class="col-md-2">
								<div id="circle" data-percent="50"></div>
								<p>Circular Progress Bar</p>
							</div>
							<div class="col-md-2">
								<div id="circle2" data-percent="39"></div>
								<p>Circular Progress Bar</p>
							</div>
							<div class="col-md-2">
								<div id="circle3" data-percent="90"></div>
								<p>Circular Progress Bar</p>
							</div>
							<div class="col-md-2">
								<div id="circle4" data-percent="60"></div>
								<p>Circular Progress Bar</p>
							</div>
							<div class="col-md-2">
								<div id="circle5" data-percent="80"></div>
								<p>Circular Progress Bar</p>
							</div>
							<div class="col-md-2">
								<div id="circle6" data-percent="45"></div>
								<p>Circular Progress Bar</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!-- Product Box -->
			<div class="product-box">
				<div class="container">
					<h3>Our Products</h3>
					<div id="carousel-example-generic4" class="carousel slide" data-ride="carousel">

						<!-- Wrapper for slides -->
						<div class="carousel-inner">

							<div class="item active">
								<div class="row">
									<div class="col-md-3">
										<div class="product-post">
											<div class="product-post-gal">
												<img alt="" src="upload/image1.jpg">
												<span class="price">$99.00</span>
											</div>
											<div class="product-post-content">
												<h5>Product Name Here</h5>
												<ul class="product-list">
													<li><a class="like" href="#"><i class="fa fa-heart"></i></a></li>
													<li><a class="shop" href="#"><i class="fa fa-shopping-cart"></i></a></li>
													<li><a class="rev" href="#"><i class="fa fa-exchange"></i></a></li>
												</ul>
											</div>
										</div>
									</div>

									<div class="col-md-3">
										<div class="product-post">
											<div class="product-post-gal">
												<img alt="" src="upload/image5.jpg">
												<span class="price">$30.00</span>
											</div>
											<div class="product-post-content">
												<h5>Product Name Here</h5>
												<ul class="product-list">
													<li><a class="like" href="#"><i class="fa fa-heart"></i></a></li>
													<li><a class="shop" href="#"><i class="fa fa-shopping-cart"></i></a></li>
													<li><a class="rev" href="#"><i class="fa fa-exchange"></i></a></li>
												</ul>
											</div>
										</div>
									</div>

									<div class="col-md-3">
										<div class="product-post">
											<div class="product-post-gal">
												<img alt="" src="upload/image6.jpg">
												<span class="price">$60.00</span>
											</div>
											<div class="product-post-content">
												<h5>Product Name Here</h5>
												<ul class="product-list">
													<li><a class="like" href="#"><i class="fa fa-heart"></i></a></li>
													<li><a class="shop" href="#"><i class="fa fa-shopping-cart"></i></a></li>
													<li><a class="rev" href="#"><i class="fa fa-exchange"></i></a></li>
												</ul>
											</div>
										</div>
									</div>

									<div class="col-md-3">
										<div class="product-post">
											<div class="product-post-gal">
												<img alt="" src="upload/image7.jpg">
												<span class="price">$55.00</span>
											</div>
											<div class="product-post-content">
												<h5>Product Name Here</h5>
												<ul class="product-list">
													<li><a class="like" href="#"><i class="fa fa-heart"></i></a></li>
													<li><a class="shop" href="#"><i class="fa fa-shopping-cart"></i></a></li>
													<li><a class="rev" href="#"><i class="fa fa-exchange"></i></a></li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="item">
								<div class="row">
									<div class="col-md-3">
										<div class="product-post">
											<div class="product-post-gal">
												<img alt="" src="upload/image7.jpg">
												<span class="price">$99.00</span>
											</div>
											<div class="product-post-content">
												<h5>Product Name Here</h5>
												<ul class="product-list">
													<li><a class="like" href="#"><i class="fa fa-heart"></i></a></li>
													<li><a class="shop" href="#"><i class="fa fa-shopping-cart"></i></a></li>
													<li><a class="rev" href="#"><i class="fa fa-exchange"></i></a></li>
												</ul>
											</div>
										</div>
									</div>

									<div class="col-md-3">
										<div class="product-post">
											<div class="product-post-gal">
												<img alt="" src="upload/image6.jpg">
												<span class="price">$30.00</span>
											</div>
											<div class="product-post-content">
												<h5>Product Name Here</h5>
												<ul class="product-list">
													<li><a class="like" href="#"><i class="fa fa-heart"></i></a></li>
													<li><a class="shop" href="#"><i class="fa fa-shopping-cart"></i></a></li>
													<li><a class="rev" href="#"><i class="fa fa-exchange"></i></a></li>
												</ul>
											</div>
										</div>
									</div>

									<div class="col-md-3">
										<div class="product-post">
											<div class="product-post-gal">
												<img alt="" src="upload/image5.jpg">
												<span class="price">$60.00</span>
											</div>
											<div class="product-post-content">
												<h5>Product Name Here</h5>
												<ul class="product-list">
													<li><a class="like" href="#"><i class="fa fa-heart"></i></a></li>
													<li><a class="shop" href="#"><i class="fa fa-shopping-cart"></i></a></li>
													<li><a class="rev" href="#"><i class="fa fa-exchange"></i></a></li>
												</ul>
											</div>
										</div>
									</div>

									<div class="col-md-3">
										<div class="product-post">
											<div class="product-post-gal">
												<img alt="" src="upload/image1.jpg">
												<span class="price">$55.00</span>
											</div>
											<div class="product-post-content">
												<h5>Product Name Here</h5>
												<ul class="product-list">
													<li><a class="like" href="#"><i class="fa fa-heart"></i></a></li>
													<li><a class="shop" href="#"><i class="fa fa-shopping-cart"></i></a></li>
													<li><a class="rev" href="#"><i class="fa fa-exchange"></i></a></li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>

						</div>

						<!-- Controls -->
						<a class="left carousel-control" href="#carousel-example-generic4" data-slide="prev"></a>
						<a class="right carousel-control" href="#carousel-example-generic4" data-slide="next"></a>
					</div>
				</div>
			</div>

			<!-- Convertible-banner -->
			<div class="convertible-banner">
				<div class="container">
					<a href="#">Learn More</a>
					<p><span>Convertible</span> The most complete PSD Template with pixel perfect design available only on themeforest</p>
				</div>
			</div>

			<!-- accord-tabs box -->
			<div class="accord-tab-box">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<h3>Content With Accordion</h3>
							<div class="accordion-box">

								<div class="accord-elem active">
									<div class="accord-title">
										<h5><i class="fa fa-question"></i>Marketplace Basics</h5>
										<a class="accord-link" href="#"></a>
									</div>
									<div class="accord-content">
										<span class="image-content"><i class="fa fa-suitcase"></i></span>
										<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio</p>
									</div>
								</div>

								<div class="accord-elem">
									<div class="accord-title">
										<h5><i class="fa fa-question"></i>Marketplace Basics</h5>
										<a class="accord-link" href="#"></a>
									</div>
									<div class="accord-content">
										<span class="image-content"><i class="fa fa-suitcase"></i></span>
										<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio</p>
									</div>
								</div>

								<div class="accord-elem">
									<div class="accord-title">
										<h5><i class="fa fa-question"></i>Marketplace Basics</h5>
										<a class="accord-link" href="#"></a>
									</div>
									<div class="accord-content">
										<span class="image-content"><i class="fa fa-suitcase"></i></span>
										<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio</p>
									</div>
								</div>

								<div class="accord-elem">
									<div class="accord-title">
										<h5><i class="fa fa-question"></i>Marketplace Basics</h5>
										<a class="accord-link" href="#"></a>
									</div>
									<div class="accord-content">
										<span class="image-content"><i class="fa fa-suitcase"></i></span>
										<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio</p>
									</div>
								</div>

								<div class="accord-elem">
									<div class="accord-title">
										<h5><i class="fa fa-question"></i>Marketplace Basics</h5>
										<a class="accord-link" href="#"></a>
									</div>
									<div class="accord-content">
										<span class="image-content"><i class="fa fa-suitcase"></i></span>
										<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio</p>
									</div>
								</div>
								
							</div>
						</div>

						<div class="col-md-6">
							<h3>Awesome Tabs</h3>

							<div class="tab-box">
								<div class="tab-content active">
									<img alt="" src="images/icon7.png">
								</div>
								<div class="tab-content">
									<img alt="" src="images/icon7.png">
								</div>
								<div class="tab-content">
									<img alt="" src="images/icon7.png">
								</div>
							</div>
							<ul class="tab-links">
								<li><a class="tab-link1 active" href="#"><i class="fa fa-cog"></i> Powerful Admin</a></li>
								<li><a class="tab-link2" href="#"><i class="fa fa-picture-o"></i> Retina Ready</a></li>
								<li><a class="tab-link3" href="#"><i class="fa fa-leaf"></i> Pixel Perfect</a></li>
							</ul>
						</div>

					</div>
				</div>
			</div>

		</div>
		<!-- End content -->


		<!-- footer 
			================================================== -->
		<footer>
			<div class="up-footer">
				<div class="container">
					<div class="row">

						<div class="col-md-3">
							<div class="widget footer-widgets text-widget">
								<img alt="" src="images/logo.png">
								<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem</p>
							</div>
							<div class="widget footer-widgets twitter-widget">
								<h4>Recent Tweets</h4>
								<ul class="tweets">
									<li>
										<p><a class="tweet-acc" href="#">@premiumlayers</a> Thanks for the head up! :) <a href="#">http://support.envato.com</a> was very helpful</p>
										<span>3 days ago</span>
									</li>
									<li>
										<p><a class="tweet-acc" href="#">@envato</a> <a href="#">http://support.envato.com</a> </p>
										<span>4 days ago</span>
									</li>
								</ul>
							</div>
						</div>

						<div class="col-md-3">
							<div class="widget footer-widgets flickr-widget">
								<h4>Flickr Gallery</h4>
								<ul class="flickr-list">
									<li><a href="#"><img alt="" src="images/flickr1.png"></a></li>
									<li><a href="#"><img alt="" src="images/flickr2.png"></a></li>
									<li><a href="#"><img alt="" src="images/flickr3.png"></a></li>
									<li><a href="#"><img alt="" src="images/flickr4.png"></a></li>
									<li><a href="#"><img alt="" src="images/flickr5.png"></a></li>
									<li><a href="#"><img alt="" src="images/flickr6.png"></a></li>
								</ul>
							</div>
							<div class="widget footer-widgets popular-widget">
								<h4>Popular Posts</h4>
								<ul class="pop-post">
									<li><a href="#"><i class="fa fa-pencil-square-o"></i> New Search Platform Update</a></li>
									<li><a href="#"><i class="fa fa-pencil-square-o"></i> Envato's Most Wanted - $5,000 for Ghost Themes</a></li>
									<li><a href="#"><i class="fa fa-pencil-square-o"></i> Update: WordPress Theme Submission Requirements</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3">
							<div class="widget footer-widgets tag-widget">
								<h4>Tags</h4>
								<ul class="tag-widget-list">
									<li><a href="#">web design</a></li>
									<li><a href="#">coding</a></li>
									<li><a href="#">wordpress</a></li>
									<li><a href="#">woo commerce</a></li>
									<li><a href="#">php</a></li>
									<li><a href="#">photography</a></li>
								</ul>
							</div>
							<div class="widget footer-widgets message-widget">
								<h4>Send Message</h4>
								<form id="footer-contact" class="contact-work-form">
									<input type="text" name="name" id="name" placeholder="Name"/>
									<input type="text" name="mail" id="mail" placeholder="Email"/>
									<textarea name="comment" id="comment" placeholder="Message"></textarea>
									<button type="submit" name="contact-submit" class="submit_contact">
										<i class="fa fa-envelope"></i> Send
									</button>
									<div class="msg"></div>
								</form>
							</div>
						</div>

						<div class="col-md-3">
							<div class="widget footer-widgets info-widget">
								<h4>Contact Us</h4>
								<ul class="contact-list">
									<li><a class="phone" href="#"><i class="fa fa-phone"></i>9930 1234 5679</a></li>
									<li><a class="mail" href="#"><i class="fa fa-envelope"></i> contact@yourdomain.com</a></li>
									<li><a class="address" href="#"><i class="fa fa-home"></i> street address example</a></li>
								</ul>
							</div>
							<div class="widget footer-widgets work-widget">
								<h4>Working Hours</h4>
								<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum </p>
								<p class="work-time"><span>Mon - Fri</span> : 10 AM to 5 PM</p>
								<p class="work-time"><span>Sat - Sun</span> : 10 AM to 2 PM</p>
							</div>
						</div>

					</div>
				</div>
			</div>

			<div class="footer-line">
				<div class="container">
					<p>&#169; 2013 Convertible,  All Rights Reserved</p>
					<a class="go-top" href="#"></a>
				</div>
			</div>

		</footer>
		<!-- End footer -->
	</div>
	<!-- End Container -->

	<!--
	##############################
	 - ACTIVATE THE BANNER HERE -
	##############################
	-->
	<script type="text/javascript">

		var tpj=jQuery;
		tpj.noConflict();

		tpj(document).ready(function() {

		if (tpj.fn.cssOriginal!=undefined)
			tpj.fn.css = tpj.fn.cssOriginal;

			var api = tpj('.fullwidthbanner').revolution(
				{
					delay:8000,
					startwidth:1170,
					startheight:580,

					onHoverStop:"off",						// Stop Banner Timet at Hover on Slide on/off

					thumbWidth:100,							// Thumb With and Height and Amount (only if navigation Tyope set to thumb !)
					thumbHeight:50,
					thumbAmount:3,

					hideThumbs:0,
					navigationType:"bullet",				// bullet, thumb, none
					navigationArrows:"solo",				// nexttobullets, solo (old name verticalcentered), none

					navigationStyle:"round",				// round,square,navbar,round-old,square-old,navbar-old, or any from the list in the docu (choose between 50+ different item), custom


					navigationHAlign:"center",				// Vertical Align top,center,bottom
					navigationVAlign:"bottom",					// Horizontal Align left,center,right
					navigationHOffset:30,
					navigationVOffset: 40,

					soloArrowLeftHalign:"left",
					soloArrowLeftValign:"center",
					soloArrowLeftHOffset:20,
					soloArrowLeftVOffset:0,

					soloArrowRightHalign:"right",
					soloArrowRightValign:"center",
					soloArrowRightHOffset:20,
					soloArrowRightVOffset:0,

					touchenabled:"on",						// Enable Swipe Function : on/off


					stopAtSlide:-1,							// Stop Timer if Slide "x" has been Reached. If stopAfterLoops set to 0, then it stops already in the first Loop at slide X which defined. -1 means do not stop at any slide. stopAfterLoops has no sinn in this case.
					stopAfterLoops:-1,						// Stop Timer if All slides has been played "x" times. IT will stop at THe slide which is defined via stopAtSlide:x, if set to -1 slide never stop automatic

					hideCaptionAtLimit:0,					// It Defines if a caption should be shown under a Screen Resolution ( Basod on The Width of Browser)
					hideAllCaptionAtLilmit:0,				// Hide all The Captions if Width of Browser is less then this value
					hideSliderAtLimit:0,					// Hide the whole slider, and stop also functions if Width of Browser is less than this value


					fullWidth:"on",

					shadow:1								//0 = no Shadow, 1,2,3 = 3 Different Art of Shadows -  (No Shadow in Fullwidth Version !)

				});


				// TO HIDE THE ARROWS SEPERATLY FROM THE BULLETS, SOME TRICK HERE:
				// YOU CAN REMOVE IT FROM HERE TILL THE END OF THIS SECTION IF YOU DONT NEED THIS !
					api.bind("revolution.slide.onloaded",function (e) {


						jQuery('.tparrows').each(function() {
							var arrows=jQuery(this);

							var timer = setInterval(function() {

								if (arrows.css('opacity') == 1 && !jQuery('.tp-simpleresponsive').hasClass("mouseisover"))
								  arrows.fadeOut(300);
							},3000);
						})

						jQuery('.tp-simpleresponsive, .tparrows').hover(function() {
							jQuery('.tp-simpleresponsive').addClass("mouseisover");
							jQuery('body').find('.tparrows').each(function() {
								jQuery(this).fadeIn(300);
							});
						}, function() {
							if (!jQuery(this).hasClass("tparrows"))
								jQuery('.tp-simpleresponsive').removeClass("mouseisover");
						})
					});
				// END OF THE SECTION, HIDE MY ARROWS SEPERATLY FROM THE BULLETS
			});
	</script>
	<script>
		jQuery(function(){ 
			DevSolutionSkill.init('circle'); 
			DevSolutionSkill.init('circle2'); 
			DevSolutionSkill.init('circle3'); 
			DevSolutionSkill.init('circle4'); 
			DevSolutionSkill.init('circle5'); 
			DevSolutionSkill.init('circle6');
		});
	</script>
</body>
</html>