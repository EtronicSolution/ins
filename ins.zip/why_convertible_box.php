<div class="why-convertible-box">
				<div class="container">
					<div class="upper-box">
						<div class="row">
							<div class="col-md-6">
								<h1>Why choose <span>Convertible</span><i class="fa fa-question-circle"></i></h1>
								<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. <a href="#">Duis sed</a> odio sit amet nibh vulputate cursus a sit amet mauris. </p>
								<p>Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non  mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Mauris in erat justo. Nullam ac urna eu felis dapibus condimentum sit amet a augue. </p>
							</div>
							<div class="col-md-6">
								<ul class="tag-list">
									<li><a href="#"><i class="fa fa-check-circle"></i>fully responsive</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>localisation support</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>semantic and clean html/css</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>woocomerce support</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>custom widgets</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>filterable portfolio</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>+600 google fonts</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>ajax contact form</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>powerful admin</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>layered psd's</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>cooming soon page</a></li>
									<li><a href="#"><i class="fa fa-check-circle"></i>retina ready</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="down-box">
						<ul class="device-list">
							<li><img alt="" src="images/device1.png"></li>
							<li class="device2"><img alt="" src="images/device2.png"></li>
							<li class="device3"><img alt="" src="images/device3.png"></li>
							<li class="device4"><img alt="" src="images/device4.png"></li>
						</ul>
					</div>
				</div>
			</div>