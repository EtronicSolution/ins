<div class="partners">
				<div class="container">
					<h3>Partners</h3>
					<div id="carousel-example-generic2" class="carousel slide" data-ride="carousel">

						<!-- Wrapper for slides -->
						<div class="carousel-inner">

							<div class="item active">
								<ul class="partner-list">
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
								</ul>
							</div>

							<div class="item">
								<ul class="partner-list">
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
									<li><img alt="" src="images/partners.png"></li>
								</ul>
							</div>

						</div>

						<!-- Controls -->
						<a class="left carousel-control" href="#carousel-example-generic2" data-slide="prev"></a>
						<a class="right carousel-control" href="#carousel-example-generic2" data-slide="next"></a>
					</div>
					
				</div>
			</div>