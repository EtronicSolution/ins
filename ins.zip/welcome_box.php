<div class="welcome-box">
				<div class="container">
                                    
                                             <div class="main-title">
                                                 <h1>The Peoples Insurance </h1>
				</div>
			</div>
                        </div>