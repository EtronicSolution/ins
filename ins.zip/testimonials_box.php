<div class="testimonials-box">
				<div class="container">
					<h3>Client Testimonials</h3>
				</div>
				<ul class="bxslider">
					<li>
						<div class="container">
							<img alt="" src="images/client.png">
							<div class="message-content">
								<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum,</p>
								<h6>John Smith, CEO at <span>Envato</span></h6>
							</div>
						</div>
					</li>
					<li>
						<div class="container">
							<img alt="" src="images/client.png">
							<div class="message-content">
								<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum,</p>
								<h6>John Smith, CEO at <span>Envato</span></h6>
							</div>
						</div>
					</li>
					<li>
						<div class="container">
							<img alt="" src="images/client.png">
							<div class="message-content">
								<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum,</p>
								<h6>John Smith, CEO at <span>Envato</span></h6>
							</div>
						</div>
					</li>
				</ul>
			</div>