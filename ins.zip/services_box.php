<div class="services-box">
				<div class="container">
					<div class="row">

						<div class="col-md-4">
							<div class="services-post">
								<a class="services-icon1" href="#"><i class="fa fa-cogs"></i></a>
								<div class="services-post-content">
									<h4>Multipurpose</h4>
									<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p>
								</div>
							</div>
						</div>

						<div class="col-md-4">
							<div class="services-post">
								<a class="services-icon2" href="#"><i class="fa fa-desktop"></i></a>
								<div class="services-post-content">
									<h4>Flexible Design</h4>
									<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p>
								</div>
							</div>
						</div>

						<div class="col-md-4">
							<div class="services-post">
								<a class="services-icon3" href="#"><i class="fa fa-book"></i></a>
								<div class="services-post-content">
									<h4>Extended Docs</h4>
									<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p>
								</div>
							</div>
						</div>

					</div>
				</div>
				<img class="shadow-image" alt="" src="images/shadow.png">
			</div>